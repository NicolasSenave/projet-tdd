﻿# -*- coding: utf-8 -*-
"""
Application traitement de données
Module Tets_chi_deux

Ce programme permet de lancer un test d'indépendance sur deux variables.
Si une des variables est quantitative, on crée un variable quantitative 
en la découpant en intervalles.

@Auteurs :
Tanguy BARTHÉLÉMY, Killian POULAIN, Nicolas SÉNAVE
"""


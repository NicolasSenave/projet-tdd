﻿# -*- coding: utf-8 -*-
"""
Application traitement de données
Module Stat_uni

Ce programme permet de lancer un regroupement des 
vins en classes via la méthode des K-moyennes.

@Auteurs :
Tanguy BARTHÉLÉMY, Killian POULAIN, Nicolas SÉNAVE
"""


﻿# -*- coding: utf-8 -*-
"""
Application traitement de données
Module Stat_uni

Ce programme permet de lancer une analyse de statistique 
descriptive univariée.

@Auteurs :
Tanguy BARTHÉLÉMY, Killian POULAIN, Nicolas SÉNAVE
"""

